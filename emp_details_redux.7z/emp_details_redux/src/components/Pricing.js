import React from 'react';

function Pricing(props) {
    return (
        <div>
            <p className="h1">Pricing Comp</p>
        </div>
    );
}

export default Pricing;