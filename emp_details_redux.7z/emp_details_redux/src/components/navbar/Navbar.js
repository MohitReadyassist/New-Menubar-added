import React from 'react'
import {Link} from "react-router-dom";

let Navbar=()=> {
    return (
        <div>
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
       <Link to="/" className="navbar-brand">Home</Link>
      </div>
      <div className="collapse navbar-collapse">
        <ul className="collapse navbar-collapse">
           <li className="nav-item px-3">
             <Link to="/emp" className="navbar-brand">Employee</Link>
           </li>
          <li className="nav-item px-3">
            <Link to="/stock" className="navbar-brand">Stock</Link>
          </li>
          <li className="nav-item px-3">
            <Link to="/pricing" className="navbar-brand">Pricing</Link>
          </li>
        </ul>
      </div>



</nav>
            
        </div>
    )
}

export default Navbar
