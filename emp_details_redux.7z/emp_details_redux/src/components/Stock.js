import React from 'react';

function Stock(props) {
    return (
        <div>
            <p className="h1">Stocks</p>
        </div>
    );
}

export default Stock;